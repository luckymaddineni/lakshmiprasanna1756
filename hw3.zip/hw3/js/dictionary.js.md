<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dictionary</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Dictionary</h1>
    </header>
    <main>
        <input type="text" id="searchInput" placeholder="Enter a word">
        <button onclick="searchDictionary()">Search</button>
        <div id="results"></div>
    </main>
    <footer>
        <!-- Footer content here -->
    </footer>
    <script src="../js/dictionary.js"></script>
</body>
</html>
